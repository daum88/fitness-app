import React, { useState, useEffect } from "react";
import { db } from "../firebase"; // Firebase Firestore instance
import { collection, doc, getDocs, getDoc, setDoc, query, where } from "firebase/firestore";

const CoachDashboard = () => {
    const [players, setPlayers] = useState([]);
    const [selectedPlayer, setSelectedPlayer] = useState(null); // For storing player details
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [newRating, setNewRating] = useState(0); // New rating value to submit

    // Fetch players from Firestore
    useEffect(() => {
        const fetchPlayers = async () => {
            try {
                setLoading(true);
                setError(null);

                const q = query(collection(db, "users"), where("role", "==", "player"));
                const playerSnapshot = await getDocs(q);

                const playersData = playerSnapshot.docs.map((doc) => ({
                    id: doc.id,
                    ...doc.data(),
                }));

                setPlayers(playersData);
            } catch (err) {
                console.error("Error fetching players:", err);
                setError("Failed to load players. Please try again later.");
            } finally {
                setLoading(false);
            }
        };

        fetchPlayers();
    }, []);

    // Fetch player ratings and details
    const handleViewRatings = async (playerId) => {
        try {
            const playerRef = doc(db, "users", playerId);
            const playerDoc = await getDoc(playerRef);

            if (playerDoc.exists()) {
                const playerData = playerDoc.data();

                // Fetch ratings for this player
                const ratingsRef = doc(db, "ratings", playerId);
                const ratingsDoc = await getDoc(ratingsRef);

                let averageRating = "No ratings yet";
                let allRatings = [];
                if (ratingsDoc.exists() && ratingsDoc.data().ratings.length > 0) {
                    allRatings = ratingsDoc.data().ratings;
                    averageRating = (allRatings.reduce((a, b) => a + b, 0) / allRatings.length).toFixed(1);
                }

                setSelectedPlayer({
                    ...playerData,
                    id: playerId,
                    averageRating,
                    allRatings,
                });
            } else {
                alert("Player details not found!");
            }
        } catch (err) {
            console.error("Error fetching player ratings:", err);
            alert("Failed to load player ratings. Please try again later.");
        }
    };

    // Submit a new rating for the player
    const handleSubmitRating = async () => {
        if (newRating < 1 || newRating > 5) {
            alert("Please select a rating between 1 and 5.");
            return;
        }

        try {
            const ratingsRef = doc(db, "ratings", selectedPlayer.id);
            const ratingsDoc = await getDoc(ratingsRef);

            let updatedRatings = [];
            if (ratingsDoc.exists()) {
                updatedRatings = [...ratingsDoc.data().ratings, newRating];
            } else {
                updatedRatings = [newRating];
            }

            // Update Firestore with the new rating
            await setDoc(ratingsRef, { ratings: updatedRatings }, { merge: true });

            // Update local state
            const averageRating = (updatedRatings.reduce((a, b) => a + b, 0) / updatedRatings.length).toFixed(1);
            setSelectedPlayer((prev) => ({
                ...prev,
                allRatings: updatedRatings,
                averageRating,
            }));

            alert("Rating submitted successfully!");
            setNewRating(0); // Reset the rating input
        } catch (err) {
            console.error("Error submitting rating:", err);
            alert("Failed to submit rating. Please try again later.");
        }
    };

    // Close player ratings modal
    const handleCloseRatings = () => {
        setSelectedPlayer(null);
    };

    return (
        <div style={{ padding: "20px", fontFamily: "Arial, sans-serif" }}>
            <h1>Coach Dashboard</h1>
            {loading ? (
                <p>Loading players...</p>
            ) : error ? (
                <p style={{ color: "red" }}>{error}</p>
            ) : (
                <table style={{ width: "100%", borderCollapse: "collapse", marginTop: "20px" }}>
                    <thead>
                    <tr style={{ backgroundColor: "#f1f1f1", textAlign: "left" }}>
                        <th style={{ padding: "10px", border: "1px solid #ddd" }}>Name</th>
                        <th style={{ padding: "10px", border: "1px solid #ddd" }}>Email</th>
                        <th style={{ padding: "10px", border: "1px solid #ddd" }}>Actions</th>
                    </tr>
                    </thead>
                    <tbody>
                    {players.map((player) => (
                        <tr key={player.id}>
                            <td style={{ padding: "10px", border: "1px solid #ddd" }}>{player.name}</td>
                            <td style={{ padding: "10px", border: "1px solid #ddd" }}>{player.email}</td>
                            <td style={{ padding: "10px", border: "1px solid #ddd" }}>
                                <button
                                    onClick={() => handleViewRatings(player.id)}
                                    style={{
                                        padding: "5px 10px",
                                        backgroundColor: "#007bff",
                                        color: "white",
                                        border: "none",
                                        borderRadius: "5px",
                                        cursor: "pointer",
                                    }}
                                >
                                    View Ratings
                                </button>
                            </td>
                        </tr>
                    ))}
                    </tbody>
                </table>
            )}

            {/* Player Ratings Modal */}
            {selectedPlayer && (
                <div
                    style={{
                        position: "fixed",
                        top: "50%",
                        left: "50%",
                        transform: "translate(-50%, -50%)",
                        backgroundColor: "white",
                        padding: "20px",
                        borderRadius: "10px",
                        boxShadow: "0 4px 8px rgba(0, 0, 0, 0.2)",
                        zIndex: 1000,
                    }}
                >
                    <h2>Player Ratings</h2>
                    <p><strong>Name:</strong> {selectedPlayer.name}</p>
                    <p><strong>Email:</strong> {selectedPlayer.email}</p>
                    <p><strong>Average Rating:</strong> {selectedPlayer.averageRating}</p>
                    <p><strong>All Ratings:</strong> {selectedPlayer.allRatings.join(", ")}</p>
                    <div style={{ marginTop: "20px" }}>
                        <label>
                            Rate Training:
                            <select
                                value={newRating}
                                onChange={(e) => setNewRating(parseInt(e.target.value))}
                                style={{ marginLeft: "10px", padding: "5px", borderRadius: "5px" }}
                            >
                                <option value="0">Select</option>
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                                <option value="4">4</option>
                                <option value="5">5</option>
                            </select>
                        </label>
                        <button
                            onClick={handleSubmitRating}
                            style={{
                                marginLeft: "10px",
                                padding: "5px 10px",
                                backgroundColor: "#28a745",
                                color: "white",
                                border: "none",
                                borderRadius: "5px",
                                cursor: "pointer",
                            }}
                        >
                            Submit Rating
                        </button>
                    </div>
                    <button
                        onClick={handleCloseRatings}
                        style={{
                            marginTop: "20px",
                            padding: "10px 20px",
                            backgroundColor: "#007bff",
                            color: "white",
                            border: "none",
                            borderRadius: "5px",
                            cursor: "pointer",
                        }}
                    >
                        Close
                    </button>
                </div>
            )}

            {/* Modal Overlay */}
            {selectedPlayer && (
                <div
                    style={{
                        position: "fixed",
                        top: 0,
                        left: 0,
                        width: "100%",
                        height: "100%",
                        backgroundColor: "rgba(0, 0, 0, 0.5)",
                        zIndex: 999,
                    }}
                    onClick={handleCloseRatings}
                />
            )}
        </div>
    );
};

export default CoachDashboard;
