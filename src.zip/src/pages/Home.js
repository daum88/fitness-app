import React, { useState, lazy, Suspense, useEffect } from "react";
import Carousel from "../Components/Carousel";
import FilterMenu from "../Components/FilterMenu";
import { exercises } from "../data/mockData";
import "../styles.css";

const ExerciseCard = lazy(() => import("../Components/ExerciseCard"));

const Home = () => {
    const [selectedCategory, setSelectedCategory] = useState("All");
    const [isVisible, setIsVisible] = useState({
        hero: true,
        carousel: false,
        explore: false,
        benefits: false,
    });

    useEffect(() => {
        const observer = new IntersectionObserver(
            (entries) => {
                entries.forEach((entry) => {
                    if (entry.isIntersecting) {
                        setIsVisible((prev) => ({ ...prev, [entry.target.id]: true }));
                    }
                });
            },
            { threshold: 0.2 }
        );

        document.querySelectorAll("section").forEach((section) => observer.observe(section));
        return () => observer.disconnect();
    }, []);

    const filteredExercises =
        selectedCategory === "All"
            ? exercises
            : exercises.filter((exercise) => exercise.category === selectedCategory);

    return (
        <div style={{ fontFamily: "'Poppins', sans-serif", color: "#333" }}>
            {/* Hero Section */}
            <section
                id="hero"
                style={{
                    background: "linear-gradient(135deg, #007bff, #00b4d8)",
                    color: "white",
                    textAlign: "center",
                    padding: "150px 20px",
                    clipPath: "ellipse(100% 70% at 50% 30%)",
                    opacity: isVisible.hero ? 1 : 0,
                    transform: isVisible.hero ? "translateY(0)" : "translateY(50px)",
                    transition: "opacity 1s ease, transform 1s ease",
                    position: "relative",
                }}
            >
                <h1 style={{ fontSize: "3.5rem", fontWeight: "bold", lineHeight: "1.2" }}>
                    Achieve Your Fitness Goals
                </h1>
                <p style={{ fontSize: "1.4rem", margin: "20px 0" }}>
                    Customized plans, progress tracking, and more.
                </p>
                <button
                    style={{
                        marginTop: "30px",
                        padding: "14px 35px",
                        backgroundColor: "#fff",
                        color: "#007bff",
                        border: "none",
                        borderRadius: "50px",
                        fontWeight: "bold",
                        fontSize: "1.2rem",
                        cursor: "pointer",
                        transition: "background-color 0.3s ease",
                        boxShadow: "0 4px 8px rgba(0, 0, 0, 0.2)",
                    }}
                    onMouseOver={(e) => (e.target.style.backgroundColor = "#f1f1f1")}
                    onMouseOut={(e) => (e.target.style.backgroundColor = "#fff")}
                >
                    Get Started
                </button>
                <div
                    style={{
                        position: "absolute",
                        bottom: "-50px",
                        left: "0",
                        right: "0",
                        background: "url('https://via.placeholder.com/1920x300')",
                        height: "150px",
                        backgroundSize: "cover",
                        backgroundPosition: "center",
                        clipPath: "ellipse(100% 50% at 50% 100%)",
                    }}
                />
            </section>

            {/* Carousel Section */}
            <section
                id="carousel"
                style={{
                    padding: "80px 20px",
                    backgroundColor: "#f9f9f9",
                    textAlign: "center",
                    opacity: isVisible.carousel ? 1 : 0,
                    transform: isVisible.carousel ? "translateY(0)" : "translateY(50px)",
                    transition: "opacity 1s ease, transform 1s ease",
                }}
            >
                <h2
                    style={{
                        fontSize: "2.5rem",
                        color: "#007bff",
                        marginBottom: "30px",
                        fontWeight: "bold",
                    }}
                >
                    Discover Top Workouts
                </h2>
                <Carousel items={exercises.slice(0, 5)} />
            </section>

            {/* Explore Exercises Section */}
            <section
                id="explore"
                style={{
                    padding: "80px 20px",
                    backgroundColor: "#ffffff",
                    textAlign: "center",
                    borderRadius: "50px 50px 0 0",
                    opacity: isVisible.explore ? 1 : 0,
                    transform: isVisible.explore ? "translateY(0)" : "translateY(50px)",
                    transition: "opacity 1s ease, transform 1s ease",
                }}
            >
                <h2
                    style={{
                        fontSize: "2.5rem",
                        color: "#007bff",
                        marginBottom: "30px",
                        fontWeight: "bold",
                    }}
                >
                    Browse Exercises
                </h2>
                <FilterMenu
                    categories={["All", "Upper Body", "Lower Body", "Core", "Full Body"]}
                    selectedCategory={selectedCategory}
                    onCategorySelect={setSelectedCategory}
                />
                <div
                    style={{
                        display: "grid",
                        gridTemplateColumns: "repeat(auto-fill, minmax(220px, 1fr))",
                        gap: "20px",
                        marginTop: "30px",
                    }}
                >
                    <Suspense fallback={<p>Loading exercises...</p>}>
                        {filteredExercises.map((exercise) => (
                            <ExerciseCard
                                key={exercise.id}
                                name={exercise.name}
                                difficulty={exercise.difficulty}
                            />
                        ))}
                    </Suspense>
                </div>
            </section>

            {/* Benefits Section */}
            <section
                id="benefits"
                style={{
                    padding: "100px 20px",
                    background: "linear-gradient(135deg, #007bff, #0096c7)",
                    color: "white",
                    textAlign: "center",
                    borderRadius: "50px 50px 0 0",
                    opacity: isVisible.benefits ? 1 : 0,
                    transform: isVisible.benefits ? "translateY(0)" : "translateY(50px)",
                    transition: "opacity 1s ease, transform 1s ease",
                }}
            >
                <h2 style={{ fontSize: "2.5rem", marginBottom: "30px", fontWeight: "bold" }}>
                    Why Fitness Hub?
                </h2>
                <div
                    style={{
                        display: "flex",
                        justifyContent: "space-around",
                        gap: "40px",
                        flexWrap: "wrap",
                        marginTop: "30px",
                    }}
                >
                    {[
                        {
                            title: "Personalized Plans",
                            description: "Custom plans to suit your goals.",
                        },
                        {
                            title: "Track Progress",
                            description: "Detailed insights and analytics.",
                        },
                        {
                            title: "Community Support",
                            description: "Motivation from like-minded fitness lovers.",
                        },
                    ].map((benefit, index) => (
                        <div
                            key={index}
                            style={{
                                maxWidth: "280px",
                                padding: "20px",
                                background: "rgba(255, 255, 255, 0.15)",
                                borderRadius: "15px",
                                textAlign: "center",
                                color: "white",
                                backdropFilter: "blur(20px)",
                                boxShadow: "0 10px 20px rgba(0, 0, 0, 0.2)",
                                transition: "transform 0.3s ease",
                            }}
                            onMouseOver={(e) => {
                                e.currentTarget.style.transform = "scale(1.1)";
                            }}
                            onMouseOut={(e) => {
                                e.currentTarget.style.transform = "scale(1)";
                            }}
                        >
                            <h3 style={{ fontSize: "1.5rem", fontWeight: "bold" }}>{benefit.title}</h3>
                            <p style={{ marginTop: "10px", fontSize: "1rem" }}>{benefit.description}</p>
                        </div>
                    ))}
                </div>
            </section>
        </div>
    );
};

export default Home;
