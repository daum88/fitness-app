import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { auth } from "../firebase"; // Ensure Firebase is correctly configured
import { signOut, onAuthStateChanged } from "firebase/auth";
import "./Navbar.css";

const Navbar = () => {
    const [isLoggedIn, setIsLoggedIn] = useState(false);
    const navigate = useNavigate();

    useEffect(() => {
        const unsubscribe = onAuthStateChanged(auth, (user) => {
            setIsLoggedIn(!!user); // Update the logged-in state
        });

        return () => unsubscribe();
    }, []);

    const handleLogout = async () => {
        try {
            await signOut(auth);
            navigate("/login");
        } catch (error) {
            console.error("Error logging out:", error.message);
        }
    };

    return (
        <nav>
            <div className="logo">
                <Link to="/" className="nav-link">Fitness App</Link>
            </div>
            <div className="nav-links">
                <Link to="/" className="nav-link">Home</Link>
                {!isLoggedIn && (
                    <>
                        <Link to="/login" className="nav-link">Log In</Link>
                        <Link to="/signup" className="nav-link">Register</Link> {/* Register link */}
                    </>
                )}
                {isLoggedIn && (
                    <>
                        <Link to="/dashboard" className="nav-link">Dashboard</Link>
                        <button
                            className="nav-link logout-button"
                            onClick={handleLogout}
                        >
                            Log Out
                        </button>
                    </>
                )}
            </div>
        </nav>
    );
};

export default Navbar;
